import { Application } from '@nativescript/core';

Application.run({ moduleName: 'app-root' });
const baseline = {
  drive: 1.6,     // expected strokes from tee
  approach: 2.9,  // from 150 yards
  putt: {
    3: 1.0,  // 3 ft
    10: 1.6, // 10 ft
    20: 1.9, // etc.
  }
};

document.getElementById('statsForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const drive = parseFloat(document.getElementById('drive').value);
  const approach = parseFloat(document.getElementById('approach').value);
  const putt = parseFloat(document.getElementById('putt').value);

  let sgDrive = baseline.drive - (drive > 250 ? 1.4 : 1.7); // simple model
  let sgApproach = baseline.approach - (approach / 100);    // rough model
  let sgPutt = baseline.putt[Math.round(putt)] - 1;          // assume 1 putt

  let total = sgDrive + sgApproach + sgPutt;

  document.getElementById('output').textContent =
    `Strokes Gained: ${total.toFixed(2)}`;
});
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('./service-worker.js');
}
